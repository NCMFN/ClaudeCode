Protocol tables are included as booktabs fragments in ../tables. No results text is included because status is PROPOSED.
