# Revision log

- The conceptual methodology figure was generated and opened for inspection. It shows six connected boxes (data, sampling, causal features, purge gap, splits, metrics), a single chronological split on a time axis with train, validation and test blocks separated by hatched gaps, and four rolling-origin folds, each with a training block, a hatched gap and a test block. It contains no numbers.
- Tables hold protocol definitions only. No measured values.
