# How to Update This Repository on GitHub

A simple guide for keeping your Claude Code resources repo up to date.

---

## Option 1 — Edit Directly on GitHub (No Terminal Needed)

This is the easiest method if you're not comfortable with the command line.

1. Go to your repository on **github.com**
2. Click the file you want to edit (`README.md` or `RESOURCES.md`)
3. Click the **pencil ✏️ icon** (Edit this file)
4. Make your changes in the editor
5. Scroll down and click **"Commit changes"**
6. Add a short commit message (e.g. `Update Claude Code resource list`)
7. Click **"Commit changes"** to save

---

## Option 2 — Upload Files from Your Computer

Use this method to upload the `README.md` and `RESOURCES.md` files directly.

1. Go to your repository on **github.com**
2. Click **"Add file"** → **"Upload files"**
3. Drag and drop your updated files (or click to browse)
4. Scroll down and add a commit message (e.g. `Add Claude Code resources`)
5. Click **"Commit changes"**

> **Note:** If a file with the same name already exists, GitHub will automatically replace it.

---

## Option 3 — Use the Terminal (Git)

Use this if you prefer working locally or want full control.

### First-time setup

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO
```

### Adding or updating files

```bash
# Copy your new files into the repo folder, then:
git add README.md RESOURCES.md
git commit -m "Update Claude Code resources 2026"
git push origin main
```

### If your branch is called `master` instead of `main`

```bash
git push origin master
```

---

## Keeping Resources Up to Date

When you find a new repo worth adding to the list:

1. Open `README.md`
2. Add a new row to the table, following the existing format:

```markdown
| 13 | [Repo Name](https://github.com/username/repo) | One-line description of what it does |
```

3. Commit and push (or save via GitHub's web editor)

---

## Troubleshooting

**"I can't push — permission denied"**
Make sure you're logged into GitHub and have write access to the repo. If it's not your repo, fork it first.

**"My changes aren't showing up"**
Hard-refresh the page (`Ctrl+Shift+R` or `Cmd+Shift+R`). GitHub sometimes caches pages for a few seconds.

**"The links in the table aren't working"**
Some URLs in the original list were truncated. Search the repo name on [github.com](https://github.com) to find and verify the correct full URL.

---

*For more on Claude Code, visit [docs.claude.com](https://docs.claude.com/en/docs/claude-code/overview)*
