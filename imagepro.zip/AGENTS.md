# Agent Configuration — Repository Conventions

This file is read by Jules (and compatible AI coding agents) at the start of every
session. All conventions listed here are **mandatory** and apply to every task,
regardless of scope.

---

## Output Conventions

### Images and Visual Assets

- **Always** save any generated image (chart, diagram, plot, screenshot, visual asset,
  or any binary visual output) as a real file on disk inside this repository.
- **Never** treat images as temporary, in-memory, display-only, or transient outputs.
- Store all generated images under `/assets/images/` for permanent assets or
  `/output/images/` for task-specific outputs.
- Use the naming convention `<descriptor>_<YYYYMMDD_HHMMSS>.png` (e.g.,
  `confusion_matrix_20250416_143022.png`) to guarantee uniqueness and avoid overwrites.
- After writing an image file, **always stage and commit it** as part of the same
  commit that contains the code that produced it.
- Images must appear in the diff/code panel after every session so they can be
  downloaded directly from the UI.

### Commit Discipline

- Every session must end with at least one commit that includes **all** newly created
  or modified files — code, images, configs, and documentation alike.
- Do not leave any generated output uncommitted.
- Commit messages must reference what was generated, e.g.:
  `feat: add confusion matrix chart (output/images/confusion_matrix_20250416_143022.png)`

### Directory Structure for Outputs

```
/assets/images/      ← permanent, version-controlled visual assets
/output/images/      ← per-task generated images (charts, plots, diagrams)
/output/reports/     ← generated reports, CSVs, or structured data exports
```

### Code Requirements for Image Generation

When writing or modifying code that produces images, the implementation **must**:

1. Resolve the output path relative to the repository root (never use `/tmp` or
   in-memory buffers as the final destination).
2. Create parent directories if they do not exist (`os.makedirs(..., exist_ok=True)`
   in Python; `fs.mkdirSync(..., { recursive: true })` in Node).
3. Save the file explicitly before the script exits.
4. Log the full resolved path of each saved file to stdout so it is visible in the
   Jules task log.

**Python template (mandatory pattern):**

```python
import os
from datetime import datetime

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "output", "images")
os.makedirs(OUTPUT_DIR, exist_ok=True)

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
filename = f"<descriptor>_{timestamp}.png"
filepath = os.path.join(OUTPUT_DIR, filename)

# --- your plotting / image-generation code here ---
fig.savefig(filepath, dpi=150, bbox_inches="tight")   # matplotlib example
# img.save(filepath)                                   # PIL example
# plt.savefig(filepath)                               # seaborn example

print(f"[IMAGE SAVED] {filepath}")
```

**Node / JS template (mandatory pattern):**

```javascript
const path = require("path");
const fs   = require("fs");

const OUTPUT_DIR = path.resolve(__dirname, "..", "output", "images");
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
const filepath  = path.join(OUTPUT_DIR, `<descriptor>_${timestamp}.png`);

// --- your image-generation / canvas code here ---
fs.writeFileSync(filepath, imageBuffer);
console.log(`[IMAGE SAVED] ${filepath}`);
```

---

## General Agent Behaviour

- Read this file at the **start** of every session before planning any task.
- If a task involves data analysis, ML model evaluation, report generation, or any
  workflow that might produce a visual, assume image output is required and apply the
  conventions above automatically.
- Do not ask the user to confirm image-saving behaviour — it is always required.
- When in doubt, save more files rather than fewer.

---

## Session Checklist (complete before ending every session)

- [ ] All generated images exist on disk under `/assets/images/` or `/output/images/`
- [ ] All output files are committed and appear in the diff panel
- [ ] Commit message references the generated files by name
- [ ] No outputs remain only in memory, in `/tmp`, or displayed inline without a saved file
