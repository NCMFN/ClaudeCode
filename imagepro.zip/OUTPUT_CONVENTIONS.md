# Repository Output Conventions

> **This section is automatically enforced.** See `AGENTS.md` for the full agent
> specification. This README excerpt is for human contributors.

---

## Image and Visual Output

All generated images — charts, diagrams, ML evaluation plots, screenshots, or any
other visual output — must be saved as committed files in this repository.

### Where images go

| Directory | Purpose |
|-----------|---------|
| `/assets/images/` | Permanent, reusable visual assets (logos, diagrams kept across tasks) |
| `/output/images/` | Per-session generated outputs (charts, plots, evaluation figures) |

### Naming convention

```
<descriptor>_<YYYYMMDD_HHMMSS>.png
```

Examples:
- `confusion_matrix_20250416_143022.png`
- `roc_curve_20250416_143055.png`
- `feature_importance_20250416_143110.png`

### Python quick-start

```python
from scripts.image_saver import save_figure, save_image_bytes, save_pil_image

# matplotlib
save_figure(fig, "confusion_matrix")

# PIL
save_pil_image(img, "roc_curve")

# raw bytes
save_image_bytes(png_bytes, "shap_summary")
```

All three helpers automatically:
- Create the output directory if it doesn't exist
- Apply the timestamp naming convention
- Print `[IMAGE SAVED] <path>` to stdout for the Jules task log

### Why this matters

Jules (and other AI agents) can only make files downloadable through the diff/code
panel if those files are **committed to the repository**. In-memory or `/tmp` images
are lost at the end of the session. Following these conventions ensures every visual
output survives the session and is immediately downloadable.
