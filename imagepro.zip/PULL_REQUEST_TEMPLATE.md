---
name: Task / Session Output
about: Checklist for every Jules session that generates files
title: "[SESSION] "
labels: []
assignees: []
---

## What was generated?

<!-- Describe the task and its outputs -->

## Image / Visual Output Checklist

- [ ] All generated images are saved under `/assets/images/` or `/output/images/`
- [ ] Image files follow the naming convention `<descriptor>_<YYYYMMDD_HHMMSS>.png`
- [ ] All image files are included in this commit / PR
- [ ] Images are visible in the diff panel and downloadable

## Files added or modified

<!-- List all new or changed files -->

## Notes

<!-- Any additional context -->
