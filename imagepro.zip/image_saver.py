"""
image_saver.py — Shared utility for saving generated images to the repository.

Usage
-----
from scripts.image_saver import save_figure, save_image_bytes

# matplotlib
save_figure(fig, "confusion_matrix")

# PIL / raw bytes
save_image_bytes(png_bytes, "roc_curve")
"""

from __future__ import annotations

import os
from datetime import datetime
from pathlib import Path
from typing import Union

# ---------------------------------------------------------------------------
# Repository-relative output directories
# ---------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parent.parent
ASSET_DIR  = _REPO_ROOT / "assets"  / "images"   # permanent assets
OUTPUT_DIR = _REPO_ROOT / "output"  / "images"   # per-task outputs

def _ensure_dir(directory: Path) -> Path:
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _make_path(descriptor: str, directory: Path, ext: str = "png") -> Path:
    """Return a unique, timestamped file path."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe_desc = descriptor.replace(" ", "_").lower()
    return directory / f"{safe_desc}_{timestamp}.{ext}"


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def save_figure(
    fig,
    descriptor: str,
    *,
    directory: Union[str, Path, None] = None,
    dpi: int = 150,
    ext: str = "png",
) -> Path:
    """
    Save a matplotlib (or compatible) Figure to the repository.

    Parameters
    ----------
    fig        : matplotlib Figure
    descriptor : short human-readable label (e.g. "confusion_matrix")
    directory  : override output directory (defaults to OUTPUT_DIR)
    dpi        : resolution
    ext        : file extension (default "png")

    Returns
    -------
    Path  — absolute path of the saved file
    """
    out_dir  = _ensure_dir(Path(directory) if directory else OUTPUT_DIR)
    filepath = _make_path(descriptor, out_dir, ext)
    fig.savefig(filepath, dpi=dpi, bbox_inches="tight")
    print(f"[IMAGE SAVED] {filepath}")
    return filepath


def save_image_bytes(
    data: bytes,
    descriptor: str,
    *,
    directory: Union[str, Path, None] = None,
    ext: str = "png",
) -> Path:
    """
    Save raw image bytes (e.g. from PIL, OpenCV, or any bytes object).

    Parameters
    ----------
    data       : raw image bytes
    descriptor : short human-readable label
    directory  : override output directory (defaults to OUTPUT_DIR)
    ext        : file extension

    Returns
    -------
    Path  — absolute path of the saved file
    """
    out_dir  = _ensure_dir(Path(directory) if directory else OUTPUT_DIR)
    filepath = _make_path(descriptor, out_dir, ext)
    filepath.write_bytes(data)
    print(f"[IMAGE SAVED] {filepath}")
    return filepath


def save_pil_image(
    img,
    descriptor: str,
    *,
    directory: Union[str, Path, None] = None,
    ext: str = "png",
) -> Path:
    """
    Save a PIL/Pillow Image object.

    Parameters
    ----------
    img        : PIL.Image.Image
    descriptor : short human-readable label
    directory  : override output directory (defaults to OUTPUT_DIR)
    ext        : file extension

    Returns
    -------
    Path  — absolute path of the saved file
    """
    out_dir  = _ensure_dir(Path(directory) if directory else OUTPUT_DIR)
    filepath = _make_path(descriptor, out_dir, ext)
    img.save(str(filepath))
    print(f"[IMAGE SAVED] {filepath}")
    return filepath
